#include <stdio.h>
#include <stdlib.h>
#include "hash.c"

void main()
{
    int tamanho;
    FILE *arquivo;

    tamanho = inicializaTamanho(arquivo);
    TDados *hash[tamanho];

    inicializa(hash, tamanho);

    inserirNaHash(hash, tamanho, arquivo);

    menu(hash, tamanho);
}