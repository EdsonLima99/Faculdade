#include <stdio.h>
#include <stdlib.h>

/*Estrutura com nome string do tipo char*/
typedef char string[300];

/*Estrutura da lista*/
typedef struct tipoDados
{
    long long matricula;
    string nome;
    struct tipoDados *prox;
} TDados;